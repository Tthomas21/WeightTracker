package com.zybooks.weighttracker;

public class User {
    private String mUserName;
    private String mPassword;
    private long mId;

    public User() {}

    public User(String userName, String password) {
        mUserName = userName;
        mPassword = password;
    }

    public void setUserName(String userName) {this.mUserName = userName; }
    public void setPassword(String password) {this.mPassword =  password; }
    public void setId(long id) {mId = id; }
    public long getId() {return mId;}

    public String getUserName() {return mUserName; }
    public String getPassword() {return mPassword; }


}
