package com.zybooks.weighttracker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    private Context context;
    Activity activity;
    private ArrayList weight;
    private ArrayList r_id;
    private int position;
    private String date_n = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(new Date());
    CustomAdapter(Activity activity, Context context, ArrayList weight, ArrayList r_id) {
        this.activity = activity;
        this.context = context;
        this.weight = weight;
        this.r_id = r_id;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.weight_rows, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
       // this.position = position;
        holder.idWeight.setText(String.valueOf(weight.get(position)));
        holder.rowId.setText(String.valueOf(r_id.get(position)));
        holder.date.setText(date_n);
        holder.rowLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateWeightActivity.class);
                intent.putExtra("WEIGHT", String.valueOf(weight.get(position)));
                intent.putExtra("id", String.valueOf(r_id.get(position)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivityForResult(intent, 1);
            }
        });

    }

    @Override
    public int getItemCount() {
        return weight.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView idWeight;
        private TextView rowId;
        private TextView date;
        ConstraintLayout rowLayout;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            rowId = itemView.findViewById(R.id._id);
            idWeight = itemView.findViewById(R.id.idWeight);
            rowLayout = itemView.findViewById(R.id.layout);
            date = itemView.findViewById(R.id.date);

        }
    }
}
