package com.zybooks.weighttracker;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class WeightActivity extends AppCompatActivity {

   private RecyclerView recyclerView;
   private FloatingActionButton addButton;
   private DatabaseHelper db;
   private ArrayList weights, r_id;
   private CustomAdapter customAdapter;
   private User user;
   private String userName;
   private Intent intent;
   private final int REQUEST_CODE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
        intent = getIntent();
        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        db = DatabaseHelper.getInstance(getApplicationContext());
        weights = new ArrayList<>();
        r_id = new ArrayList<>();


        // store data in arrays
        storeData();
        customAdapter = new CustomAdapter( WeightActivity.this, this, weights, r_id);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(WeightActivity.this));


        // Start method
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WeightActivity.this, AddWeightActivity.class);
                startActivity(intent);
            }
        });
        // end method
    }

    // refresh activity when object is updated
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    // Method to store and display weight objects
    void storeData() {
        Cursor cursor = db.readAllData();
        if (cursor.getCount() == 0){
            Toast.makeText(WeightActivity.this, "No data to display", Toast.LENGTH_SHORT).show();
        } else {
            while(cursor.moveToNext()) {
                r_id.add(cursor.getString( 0));
                weights.add(cursor.getString( 1));
            }
        }
    }

    // Method to inflate options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Delete all method
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == R.id.action_delete){
            confirmDialog();
        }
        return super.onOptionsItemSelected(item);
    }

    // confirmation dialog for delete action
    void confirmDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(WeightActivity.this);
        builder.setTitle("Delete Weight");
        builder.setMessage("Are you sure you want to delete all weight entries?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                db.DeleteAllWeightData();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();

    }

}