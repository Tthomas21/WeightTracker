package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class SetGoalWeight extends AppCompatActivity {

    private EditText eWeight;
    private Button save;
    private Switch smsPref;
    private DatabaseHelper db;
    private static final int REQUEST_SEND_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_goal_weight);
        eWeight = findViewById(R.id.inputWeight);
        save = findViewById(R.id.addWeight2);
        smsPref = findViewById(R.id.smsPref);
        db = DatabaseHelper.getInstance(getApplicationContext());
        smsPref.setChecked(false);

        // This will allow the user to store their goal weight in the goal weight table
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputWeight = eWeight.getText().toString();
                if (inputWeight.isEmpty()){
                    Toast.makeText(SetGoalWeight.this, "Please Enter a weight", Toast.LENGTH_SHORT).show();
                } else {
                    int weight = Integer.valueOf(eWeight.getText().toString());
                    db.AddGoalWeight(weight);
                }
            }
        });

        // This button will trigger permission request
        smsPref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(SetGoalWeight.this,
                        Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {
                    if(ActivityCompat.shouldShowRequestPermissionRationale(SetGoalWeight.this,
                            Manifest.permission.SEND_SMS)) {

                    } else {
                        ActivityCompat.requestPermissions(SetGoalWeight.this,
                                new String[]{Manifest.permission.SEND_SMS},
                                REQUEST_SEND_SMS);
                    }

                }

            }


        });

    }
    // I was able to successfully set permissions for sending SMS, was unsurre of appropriate methods to use for triggering a sms to be sent
    @Override
    public void onRequestPermissionsResult(int requestCode, String permission[], int[] grantResults){

        //check request code
        switch (requestCode){
            case REQUEST_SEND_SMS:
            {
                // check if permissioion was granted
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){

                    Toast.makeText(SetGoalWeight.this, "You will now receive a notification when you reach your goal weight", Toast.LENGTH_SHORT).show();
                    smsPref.setEnabled(true);
                } else {
                    Toast.makeText(SetGoalWeight.this, "Permission to receive SMS notifications denied", Toast.LENGTH_SHORT).show();
                }

            }


        }
    }


}