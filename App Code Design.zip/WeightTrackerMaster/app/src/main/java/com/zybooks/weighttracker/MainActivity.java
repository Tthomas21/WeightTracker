package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText eUserName;
    private EditText ePassword;
    private Button eLogin;
    private Button createAccount;
    private DatabaseHelper mWeightDB;
    private User mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eUserName = findViewById(R.id.eUserName);
        ePassword = findViewById(R.id.ePassword);
        eLogin = findViewById(R.id.login);
        createAccount = findViewById(R.id.createAccount);

        mWeightDB = DatabaseHelper.getInstance(getApplicationContext());

        /*
         * Button listener for login click
         */
        eLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String inputUserName = eUserName.getText().toString();
                String inputPassword = ePassword.getText().toString();
                // User login logic
                if(inputUserName.isEmpty() || inputPassword.isEmpty()){
                    Toast.makeText(MainActivity.this, "You have not entered all of the required login credentials", Toast.LENGTH_SHORT).show();

                }else {
                    // Build method to check credentials against the database
                    mUser = new User(inputUserName, inputPassword);
                    Boolean checkUser = mWeightDB.validateUser(mUser);
                    if (checkUser == true){
                        Intent intent = new Intent(MainActivity.this, WeightActivity.class);
                        startActivity(intent);
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Incorrect Login, please retry", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        /*
         *Button listener for create account click
         */
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String inputUserName = eUserName.getText().toString();
                String inputPassword = ePassword.getText().toString();
                // Check if the username already exists
                // Ensure password is greater than 8 characters
                // Provide confirmation that user account was successfully created
                if(inputUserName.isEmpty() || inputPassword.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter a user name and password", Toast.LENGTH_SHORT).show();
                }
                if(inputPassword.length() < 8){
                        Toast.makeText(MainActivity.this, "Please enter a password with at least 8 characters", Toast.LENGTH_SHORT).show();
                    } else {
                        mUser = new User();
                        mUser.setUserName(inputUserName);
                        Boolean checkUserName = mWeightDB.validateUserName(inputUserName);
                        if (checkUserName == false){
                            mUser.setPassword(inputPassword);
                            Boolean insert = mWeightDB.insertNewUser(mUser);
                            Log.e(MainActivity.class.getName(), " ");
                            if(insert == true){
                                Toast.makeText(MainActivity.this, "You have successfully created an account", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, WeightActivity.class);
                                intent.putExtra("EXTRA_USER", inputUserName);
                                startActivity(intent);
                            } else {
                                Toast.makeText(MainActivity.this, "An error may have occurred, please try again", Toast.LENGTH_SHORT).show();

                            }
                        }
                    }

            }
        });
    }
}