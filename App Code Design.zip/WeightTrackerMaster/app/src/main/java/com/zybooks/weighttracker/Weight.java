package com.zybooks.weighttracker;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static android.content.ContentValues.TAG;

public class Weight {
    private int mWeight;
    private long id;





    public Weight(int weight){
        this.mWeight = weight;
    }

    public Weight(int weight, int id){

        this.mWeight = weight;
        this.id = id;
    }



    public long getWeight() {return this.mWeight; }

    public void setWeight(int weight) {this.mWeight = weight; }

    public long getId() {return id; }

    public void setId(long id) {this.id = id; }


}
