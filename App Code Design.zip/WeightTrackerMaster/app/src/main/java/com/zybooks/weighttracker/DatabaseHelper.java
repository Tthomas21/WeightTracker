package com.zybooks.weighttracker;

import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "weight.db";
    private Context context;
    private Weight weights;

    private static DatabaseHelper mWeightDb;

    public static DatabaseHelper getInstance(Context context) {
        if (mWeightDb == null) {
            mWeightDb = new DatabaseHelper(context);
        }
        return mWeightDb;
    }

    private DatabaseHelper(Context context) {super (context, DATABASE_NAME, null, VERSION); }

    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USER_NAME = "user_name";
        private static final String COL_PASSWORD = "password";
    }

    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_ID_WEIGHT = "weightId";
    }

    private static final class GoalWeightTable {
        private static final String TABLE = "goal_weight";
        private static final String COL_GOAL_ID = "goal_id";
        private static final String COL_GOAL_WEIGHT = "goal_weight";


    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // Creates User table
        db.execSQL("create table " + UserTable.TABLE +" (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USER_NAME + " text, "+
                UserTable.COL_PASSWORD + " text)");

        // Creates weight table
        db.execSQL("create table " + WeightTable.TABLE +" (" +
                WeightTable.COL_ID_WEIGHT + " integer primary key autoincrement, " +
                WeightTable.COL_WEIGHT + " int) ");

        // Creates goal weight table
        // Foreign key to match weight table
        db.execSQL("create table " + GoalWeightTable.TABLE +" (" +
                GoalWeightTable.COL_GOAL_ID + " integer primary key autoincrement, " +
                GoalWeightTable.COL_GOAL_WEIGHT + " int) ");

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        db.execSQL("drop table if exists " + GoalWeightTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }
    // Method to insert a new user to user table
    public Boolean insertNewUser(User user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(UserTable.COL_USER_NAME, user.getUserName());
        contentValues.put(UserTable.COL_PASSWORD, user.getPassword());
        long id = db.insert(UserTable.TABLE, null, contentValues);
        return id != -1;
    }

    // Method to validate if a giver user name already exists in the table
    public Boolean validateUserName(String userName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + UserTable.TABLE + " WHERE " + UserTable.COL_USER_NAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    // Method to validate both username and password at once
    public Boolean validateUser(User user){
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "Select * from " + UserTable.TABLE +
                " where " + UserTable.COL_USER_NAME + " =?" +
                " and " + UserTable.COL_PASSWORD + " =?" ;
        Cursor cursor = db.rawQuery(sql, new String[] {user.getUserName(), user.getPassword()});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }
    // Method to add weight to table
    public long AddWeight(Weight weight){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(WeightTable.COL_WEIGHT, weight.getWeight());
        long id = db.insert(WeightTable.TABLE, null, cv);

        return id;
    }
    // Read all data from weight table
    Cursor readAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "select * from " + WeightTable.TABLE;
        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(sql, null);
        }
        return cursor;
    }

    // Update selected weight data
    void UpdateWeightData(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(WeightTable.COL_WEIGHT, weight.getWeight());
        db.update(WeightTable.TABLE, cv,  WeightTable.COL_ID_WEIGHT + " = " + weight.getId(), null);
    }

    // Delete one selected row from Weight database table
    public long DeleteWeightData(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(WeightTable.TABLE, WeightTable.COL_ID_WEIGHT + " = " + weight.getId(), null);

        return result;
    }
    // Delete all weight from weight table
    public long DeleteAllWeightData(){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(WeightTable.TABLE, null, null);
        db.close();

        return result;
    }
    // store goal weight in goal weight table
    public long AddGoalWeight(int weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(GoalWeightTable.TABLE, weight);
        long id = db.insert(GoalWeightTable.TABLE, null, cv);

        return id;

    }

    // delete all from goal weight table
    public long DeleteGoalWeight(){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(GoalWeightTable.TABLE,null,null);
        db.close();
        return result;
    }


}
