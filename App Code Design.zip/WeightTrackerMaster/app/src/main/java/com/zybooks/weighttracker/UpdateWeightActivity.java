package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class UpdateWeightActivity extends AppCompatActivity {

    private static final String TAG = null;
    private EditText inWeight;
    private TextView idWeight;
    private Button inNewBtn, delete;
    private String weight, id;
    private DatabaseHelper db;
    private Weight newWeight;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_weight);

        inWeight = findViewById(R.id.newWeight);
        inNewBtn = findViewById(R.id.updateWeight);
        idWeight = findViewById(R.id.idWeight);
        delete = findViewById(R.id.deleteWeight);
        db = DatabaseHelper.getInstance(getApplicationContext());
        getIntentData();
        inNewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputWeight = inWeight.getText().toString();
                if (inputWeight.equals("")) {
                   Toast.makeText(UpdateWeightActivity.this, "Please enter a value", Toast.LENGTH_SHORT).show();
                } else {
                    int weightV = Integer.parseInt(inWeight.getText().toString());
                    int _id = Integer.valueOf(idWeight.getText().toString());
                    newWeight = new Weight(weightV, _id);
                    db.UpdateWeightData(newWeight);
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDialog();

            }
        });


    }
    void getIntentData() {
        if(getIntent().hasExtra("WEIGHT") && getIntent().hasExtra("id")) {

            // Get Intent data
            weight = getIntent().getStringExtra("WEIGHT");
            id = getIntent().getStringExtra("id");
            Log.e(TAG, " " + id);

            // Set intent data
            inWeight.setText(weight);
            idWeight.setText(id);

        } else {
            Toast.makeText(UpdateWeightActivity.this, "No Data to display", Toast.LENGTH_SHORT).show();
        }


    }

    // confirmation dialog for delete action
    void confirmDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateWeightActivity.this);
        builder.setTitle("Delete Weight");
        builder.setMessage("Are you sure you want to delete all weight entries?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                int weightV = Integer.parseInt(inWeight.getText().toString());
                int _id = Integer.valueOf(idWeight.getText().toString());
                newWeight = new Weight(weightV, _id);
                long result =  db.DeleteWeightData(newWeight);
                if(result == -1){
                    Toast.makeText(UpdateWeightActivity.this, "Delete was not successful", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(UpdateWeightActivity.this, "Delete was successful", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();

    }

}
