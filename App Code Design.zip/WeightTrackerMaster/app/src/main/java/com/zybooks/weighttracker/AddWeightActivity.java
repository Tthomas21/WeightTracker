package com.zybooks.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddWeightActivity extends AppCompatActivity {

    private EditText mWeight;
    private Button addWeight, goalWeight;
    private DatabaseHelper db;
    private Weight inWeight;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        mWeight = findViewById(R.id.eWeight);
        addWeight = findViewById(R.id.addWeight);
        goalWeight = findViewById(R.id.setWeight);

        db = DatabaseHelper.getInstance(getApplicationContext());
        // implementation for creating a new weight
        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputWeight = mWeight.getText().toString();
                if (inputWeight.equals("") ) {
                    Toast.makeText(AddWeightActivity.this, "Please Enter a value, and ensure it is greater than 0", Toast.LENGTH_SHORT).show();
                } else {
                    int weight = Integer.parseInt(mWeight.getText().toString());
                    inWeight = new Weight(weight);
                    long insert = db.AddWeight(inWeight);
                    inWeight.setId(insert);
                    if (insert != -1){
                        Toast.makeText(AddWeightActivity.this, "Weight has been added", Toast.LENGTH_SHORT).show();

                        } else {
                        Toast.makeText(AddWeightActivity.this, "An error occurred please try again", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        }); // end addWeight

        // goal weight onClick to start set goal weight activity
        goalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddWeightActivity.this, SetGoalWeight.class);
                startActivity(intent);
            }
        }); // goalWeight onclick


    } // onCreate
}